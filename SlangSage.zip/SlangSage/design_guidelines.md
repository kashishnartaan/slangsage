# SlangBridge Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from gaming interfaces like Duolingo, Discord, and modern meme apps like TikTok, combined with brain rot aesthetic elements. The app should feel like a fun mobile game rather than a traditional dictionary.

## Core Design Elements

### Color Palette
**Primary Colors (Dark Mode)**:
- Background: 220 15% 8% (deep dark purple-gray)
- Card backgrounds: 240 12% 15% (slightly lighter purple-gray)
- Primary brand: 280 100% 70% (vibrant purple - very Gen Z)
- Text primary: 0 0% 95% (near white)

**Accent Colors**:
- Success/correct: 120 60% 60% (lime green - brain rot style)
- Warning: 30 100% 65% (orange)
- Meme highlight: 300 80% 75% (hot pink)

**Gradients**: Use throughout for cards and buttons - purple to pink gradients (280 100% 70% to 320 100% 75%)

### Typography
- **Primary**: "Inter" from Google Fonts - clean, modern
- **Display/Headers**: "Fredoka One" from Google Fonts - playful, rounded
- **Accent/Memes**: "Comic Neue" from Google Fonts - casual, meme-appropriate

### Layout System
Tailwind spacing: Primarily use units 2, 4, 6, and 8 for consistency (p-4, m-6, gap-8, etc.)

### Component Library

**Core UI Elements**:
- **Slang Cards**: Large, game-like cards with rounded corners (rounded-2xl), gradient backgrounds, and subtle shadows
- **Search Bar**: Prominent, rounded search with fun placeholder text like "Search for that word you don't understand bestie..."
- **Random Button**: Big, colorful "Surprise Me!" button with emoji

**Navigation**:
- Simple top bar with app logo/name
- Bottom navigation for core features (Search, Random, About)
- Swipe gestures for card interactions

**Data Display**:
- **Term Cards**: Each includes:
  - Large term in display font
  - Generation tag badge (Gen Z, Gen Alpha, Boomer, etc.)
  - Definition in clean typography
  - Usage context with examples
  - "Example in the wild" section with meme-style formatting

**Interactive Elements**:
- Card flip animations for definitions
- Swipe left/right for next/previous terms
- Tap interactions with subtle bounce animations
- Loading states with fun brain rot references

### Visual Themes
- **Brain Rot Aesthetic**: Incorporate popular meme formats, emoji usage, and internet culture references
- **Gaming Elements**: Progress indicators, achievement-style badges, card collection feel
- **Gen Z Visual Language**: Bold colors, informal typography, lots of emojis, ironic/self-aware design elements

### Images
No large hero image needed. Instead use:
- Small meme reaction GIFs or images within term examples
- Emoji and icon-based visual elements
- Colorful abstract shapes and gradients as decoration
- Profile-style avatars for different generations (cute cartoon style)

### Animations
- Minimal but impactful: card flips, gentle bounces on interactions
- Smooth transitions between states
- Subtle parallax effects on scroll

### Mobile-First Design
- Touch-friendly button sizes (minimum 44px)
- Thumb-reachable navigation
- Swipe gestures as primary interaction method
- Responsive text sizing for readability

The overall feel should be like a cross between a language learning game and a meme compilation app - educational but extremely entertaining and visually engaging.