import { sql } from "drizzle-orm";
import { pgTable, text, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const slangTerms = pgTable("slang_terms", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  term: text("term").notNull(),
  definition: text("definition").notNull(),
  generation: text("generation").notNull(), // 'Gen Z', 'Gen Alpha', 'Boomer', 'Millennial'
  usage: text("usage").notNull(),
  example: text("example").notNull(),
  pronunciation: text("pronunciation"),
});

export const insertSlangTermSchema = createInsertSchema(slangTerms).omit({
  id: true,
});

export type InsertSlangTerm = z.infer<typeof insertSlangTermSchema>;
export type SlangTerm = typeof slangTerms.$inferSelect;
