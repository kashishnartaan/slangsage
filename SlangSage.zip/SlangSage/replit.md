# SlangBridge

## Overview

SlangBridge is a modern web application designed to bridge generational communication gaps by providing a comprehensive dictionary of contemporary slang terms. The application helps users understand and learn slang terminology across different generations (Gen Z, Gen Alpha, Millennials, Boomers) through an interactive, game-like interface inspired by modern social platforms like TikTok, Discord, and Duolingo.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The frontend is built as a single-page application using React with TypeScript, leveraging modern web technologies for a responsive and engaging user experience:

- **Framework**: React 18 with TypeScript for type safety
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: Tailwind CSS with custom design system featuring purple/pink gradients and "brain rot" aesthetic
- **Component Library**: Radix UI primitives with custom shadcn/ui components for accessibility
- **State Management**: TanStack React Query for server state management
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
The backend follows a REST API architecture with Express.js, designed for scalability and maintainability:

- **Runtime**: Node.js with Express.js framework
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **API Design**: RESTful endpoints with proper error handling and response formatting
- **Storage Strategy**: In-memory storage with seeded data for development, designed to transition to PostgreSQL

### Database Schema
The application uses a simple but effective schema centered around slang terms:

- **slang_terms table**: Contains term, definition, generation, usage, example, and pronunciation fields
- **UUID primary keys**: For scalable identification
- **Generation categorization**: Supports Gen Z, Gen Alpha, Boomer, and Millennial classifications

### Design System
The application implements a comprehensive design system with:

- **Color Palette**: Dark mode primary with purple/pink gradients and accent colors
- **Typography**: Inter for body text, Fredoka One for headers, Comic Neue for casual elements
- **Component Variants**: Game-like cards with hover effects and interactive elements
- **Responsive Design**: Mobile-first approach with touch-friendly interactions

### API Structure
RESTful API endpoints provide comprehensive slang term management:

- `GET /api/slang` - Retrieve all terms or search with query parameter
- `GET /api/slang/random` - Get random slang term for discovery feature
- `GET /api/slang/:id` - Retrieve specific term by ID
- `POST /api/slang` - Create new slang terms (with validation)

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connectivity for production deployment
- **drizzle-orm**: Type-safe ORM for database operations with PostgreSQL dialect
- **@tanstack/react-query**: Server state management and caching
- **express**: Web framework for REST API endpoints

### UI and Styling
- **@radix-ui/***: Comprehensive set of accessible UI primitives
- **tailwindcss**: Utility-first CSS framework with custom configuration
- **class-variance-authority**: Component variant management
- **lucide-react**: Modern icon library for consistent iconography

### Development Tools
- **vite**: Build tool and development server
- **typescript**: Static type checking
- **@replit/vite-plugin-runtime-error-modal**: Development error handling
- **drizzle-kit**: Database migration and schema management

### Form and Validation
- **react-hook-form**: Form state management
- **@hookform/resolvers**: Form validation resolvers
- **zod**: Runtime type validation and schema definition