import type { SlangTerm } from '@/components/SlangCard';

// TODO: remove mock functionality - replace with real data from backend
export const mockSlangData: SlangTerm[] = [
  {
    id: '1',
    term: 'no cap',
    definition: 'No lie, for real, telling the truth',
    generation: 'Gen Z',
    usage: 'Used to emphasize that you\'re being honest or serious about something',
    example: 'That movie was actually fire, no cap!',
    pronunciation: 'noh kap'
  },
  {
    id: '2',
    term: 'rizz',
    definition: 'Charisma, charm, ability to attract someone romantically',
    generation: 'Gen Z',
    usage: 'Used to describe someone\'s charm or flirting ability',
    example: 'Bro has so much rizz, everyone loves talking to him',
    pronunciation: 'riz'
  },
  {
    id: '3',
    term: 'bussin',
    definition: 'Really good, excellent, amazing (usually about food)',
    generation: 'Gen Z',
    usage: 'Used to describe something that tastes really good or is of high quality',
    example: 'This pizza is absolutely bussin!',
    pronunciation: 'bus-sin'
  },
  {
    id: '4',
    term: 'Ohio',
    definition: 'Weird, strange, or bizarre behavior/situation',
    generation: 'Gen Alpha',
    usage: 'Used to describe something that seems off or unusual',
    example: 'That dance was so Ohio, I can\'t even...',
    pronunciation: 'oh-hi-oh'
  },
  {
    id: '5',
    term: 'skibidi',
    definition: 'Nonsense word used for emphasis or as filler',
    generation: 'Gen Alpha',
    usage: 'Often used in memes or to make things sound funnier',
    example: 'Skibidi toilet is taking over the internet',
    pronunciation: 'skib-ih-dee'
  },
  {
    id: '6',
    term: 'groovy',
    definition: 'Cool, fashionable, or excellent',
    generation: 'Boomer',
    usage: 'Popular in the 60s-70s to describe something appealing',
    example: 'That\'s a groovy outfit you\'re wearing!',
    pronunciation: 'groo-vee'
  },
  {
    id: '7',
    term: 'far out',
    definition: 'Amazing, incredible, or mind-blowing',
    generation: 'Boomer',
    usage: 'Used to express amazement or approval, popular in hippie culture',
    example: 'Far out, man! That concert was incredible!',
    pronunciation: 'fahr owt'
  },
  {
    id: '8',
    term: 'tight',
    definition: 'Cool, awesome, or close relationship',
    generation: 'Millennial',
    usage: 'Used to describe something good or a close friendship',
    example: 'We\'re tight, we\'ve been friends since college',
    pronunciation: 'tahy-t'
  },
  {
    id: '9',
    term: 'bling',
    definition: 'Flashy, expensive jewelry or accessories',
    generation: 'Millennial',
    usage: 'Used to describe ostentatious jewelry or wealth display',
    example: 'Check out all that bling on his chain!',
    pronunciation: 'bling'
  },
  {
    id: '10',
    term: 'stan',
    definition: 'To be an extremely devoted fan of someone',
    generation: 'Gen Z',
    usage: 'Used to express intense fandom or support for a celebrity/person',
    example: 'I totally stan Taylor Swift, she\'s amazing!',
    pronunciation: 'stan'
  }
];

export function getRandomSlang(): SlangTerm {
  const randomIndex = Math.floor(Math.random() * mockSlangData.length);
  return mockSlangData[randomIndex];
}

export function searchSlang(query: string): SlangTerm[] {
  if (!query.trim()) return mockSlangData;
  
  const searchTerm = query.toLowerCase();
  return mockSlangData.filter(slang => 
    slang.term.toLowerCase().includes(searchTerm) ||
    slang.definition.toLowerCase().includes(searchTerm) ||
    slang.usage.toLowerCase().includes(searchTerm)
  );
}