import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import SlangCard from '@/components/SlangCard';
import SearchBar from '@/components/SearchBar';
import RandomButton from '@/components/RandomButton';
import type { SlangTerm } from '@/components/SlangCard';

export default function Home() {
  const [currentSlang, setCurrentSlang] = useState<SlangTerm | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchMode, setIsSearchMode] = useState(false);
  const queryClient = useQueryClient();

  // Fetch all slang terms or search results
  const { data: searchResults = [], isLoading: isSearching } = useQuery<SlangTerm[]>({
    queryKey: ['/api/slang', searchQuery],
    queryFn: async () => {
      const url = searchQuery ? `/api/slang?q=${encodeURIComponent(searchQuery)}` : '/api/slang';
      const response = await fetch(url);
      if (!response.ok) throw new Error('Failed to fetch slang terms');
      return response.json();
    },
    enabled: isSearchMode || searchQuery.length > 0,
  });

  // Fetch initial random slang term
  const { data: initialSlang, isLoading: isLoadingInitial } = useQuery<SlangTerm>({
    queryKey: ['/api/slang/random', 'initial'],
    queryFn: async () => {
      const response = await fetch('/api/slang/random');
      if (!response.ok) throw new Error('Failed to fetch initial slang');
      return response.json();
    },
    enabled: !currentSlang && !isSearchMode,
  });

  // Random slang mutation
  const randomMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/slang/random');
      if (!response.ok) throw new Error('Failed to fetch random slang');
      return response.json();
    },
    onSuccess: (data: SlangTerm) => {
      setCurrentSlang(data);
      setIsSearchMode(false);
      setSearchQuery('');
    },
  });

  // Set initial slang when it loads
  useEffect(() => {
    if (initialSlang && !currentSlang) {
      setCurrentSlang(initialSlang);
    }
  }, [initialSlang, currentSlang]);

  // Set current slang from search results
  useEffect(() => {
    if (searchResults.length > 0 && isSearchMode) {
      setCurrentSlang(searchResults[0]);
    }
  }, [searchResults, isSearchMode]);

  const handleSearch = (query: string) => {
    console.log('Searching for:', query);
    setSearchQuery(query);
    
    if (!query.trim()) {
      setIsSearchMode(false);
      setSearchQuery('');
      return;
    }
    
    setIsSearchMode(true);
  };

  const handleRandom = () => {
    console.log('Getting random slang...');
    randomMutation.mutate();
  };

  const handleNext = () => {
    if (isSearchMode && searchResults.length > 1 && currentSlang) {
      const currentIndex = searchResults.findIndex(s => s.id === currentSlang.id);
      const nextIndex = (currentIndex + 1) % searchResults.length;
      setCurrentSlang(searchResults[nextIndex]);
    } else {
      handleRandom();
    }
  };

  // Show loading if we don't have any slang term yet
  if (!currentSlang && (isLoadingInitial || isSearching)) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="font-casual text-muted-foreground">Loading brain rot knowledge...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-br from-purple-900/20 via-pink-900/20 to-blue-900/20">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-pink-500/20 animate-pulse"></div>
        </div>
        
        <div className="relative container mx-auto px-4 py-12 text-center">
          <div className="max-w-3xl mx-auto">
            <h1 className="font-display text-4xl md:text-6xl lg:text-7xl text-primary mb-4" data-testid="text-hero-title">
              SlangBridge
            </h1>
            <p className="font-casual text-xl md:text-2xl text-muted-foreground mb-2">
              no cap dictionary fr fr 💯
            </p>
            <p className="text-lg text-foreground/80 mb-8 max-w-2xl mx-auto">
              Bridge the generational gap! From "bussin" to "groovy" - learn slang from every era and keep up with the brain rot ✨
            </p>
            
            {/* Search Section */}
            <div className="mb-8">
              <SearchBar onSearch={handleSearch} />
            </div>
            
            {/* Random Button */}
            <RandomButton onRandom={handleRandom} isLoading={randomMutation.isPending} />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="flex flex-col items-center space-y-8">
          {/* Search Results Info */}
          {isSearchMode && (
            <div className="text-center">
              <p className="font-casual text-lg text-muted-foreground">
                Found {searchResults.length} result{searchResults.length !== 1 ? 's' : ''} 🔍
              </p>
              {searchResults.length > 1 && currentSlang && (
                <p className="text-sm text-muted-foreground mt-1">
                  Showing result {searchResults.findIndex(s => s.id === currentSlang.id) + 1} of {searchResults.length}
                </p>
              )}
            </div>
          )}

          {/* Main Slang Card */}
          {currentSlang && <SlangCard slang={currentSlang} onNext={handleNext} />}

          {/* Navigation Hints */}
          <div className="text-center space-y-2 max-w-md">
            <p className="font-casual text-sm text-muted-foreground">
              💡 Tap the card to flip it and see the definition!
            </p>
            {!isSearchMode && (
              <p className="font-casual text-xs text-muted-foreground/70">
                Hit "Surprise Me!" for random brain rot knowledge
              </p>
            )}
            {isSearchMode && searchResults.length > 1 && (
              <p className="font-casual text-xs text-muted-foreground/70">
                Multiple results found - keep hitting "Surprise Me!" to see more
              </p>
            )}
          </div>
        </div>
      </div>

    </div>
  );
}