import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, X } from 'lucide-react';

interface SearchBarProps {
  onSearch: (query: string) => void;
  placeholder?: string;
  value?: string;
}

export default function SearchBar({ 
  onSearch, 
  placeholder = "Search for that word you don't understand bestie...", 
  value = "" 
}: SearchBarProps) {
  const [query, setQuery] = useState(value);

  const handleSearch = () => {
    onSearch(query);
    console.log('Search triggered:', query);
  };

  const handleClear = () => {
    setQuery('');
    onSearch('');
    console.log('Search cleared');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <div className="relative w-full max-w-md mx-auto">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
        <Input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder={placeholder}
          className="pl-10 pr-10 py-3 text-lg bg-card border-2 border-primary/30 rounded-xl focus:border-primary hover-elevate font-casual"
          data-testid="input-search"
        />
        {query && (
          <Button
            variant="ghost"
            size="sm"
            onClick={handleClear}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
            data-testid="button-clear-search"
          >
            <X className="w-4 h-4" />
          </Button>
        )}
      </div>
      
      {query && (
        <Button
          onClick={handleSearch}
          className="w-full mt-3 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold py-3 rounded-xl"
          data-testid="button-search"
        >
          <Search className="w-5 h-5 mr-2" />
          Search that slang! 🔍
        </Button>
      )}
    </div>
  );
}