import { Button } from '@/components/ui/button';
import { Shuffle, Sparkles } from 'lucide-react';

interface RandomButtonProps {
  onRandom: () => void;
  isLoading?: boolean;
}

export default function RandomButton({ onRandom, isLoading = false }: RandomButtonProps) {
  const handleClick = () => {
    onRandom();
    console.log('Random slang requested');
  };

  const randomEmojis = ['🎲', '✨', '🔥', '💫', '🎯', '🌟'];
  const randomEmoji = randomEmojis[Math.floor(Math.random() * randomEmojis.length)];

  return (
    <Button
      onClick={handleClick}
      disabled={isLoading}
      className="relative overflow-hidden bg-black hover:bg-gray-900 text-white font-semibold py-3 px-6 rounded-xl text-base shadow-md transform transition-all duration-200 hover:scale-105 active:scale-95 border border-gray-700"
      data-testid="button-random"
    >
      <div className="flex items-center space-x-2">
        {isLoading ? (
          <div className="animate-spin">
            <Sparkles className="w-5 h-5" />
          </div>
        ) : (
          <Shuffle className="w-5 h-5" />
        )}
        <span className="font-casual font-medium">
          {isLoading ? 'Finding...' : 'Surprise Me!'} {randomEmoji}
        </span>
      </div>
      
      {/* Animated background effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 -translate-x-full transition-transform duration-1000 ease-out group-hover:translate-x-full"></div>
    </Button>
  );
}