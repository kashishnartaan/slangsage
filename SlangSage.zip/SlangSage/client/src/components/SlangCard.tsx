import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { RotateCcw, Volume2 } from 'lucide-react';

export interface SlangTerm {
  id: string;
  term: string;
  definition: string;
  generation: 'Gen Z' | 'Gen Alpha' | 'Boomer' | 'Millennial';
  usage: string;
  example: string;
  pronunciation?: string;
}

interface SlangCardProps {
  slang: SlangTerm;
  onNext?: () => void;
}

export default function SlangCard({ slang, onNext }: SlangCardProps) {
  const [isFlipped, setIsFlipped] = useState(false);

  const getGenerationColor = (gen: string) => {
    switch (gen) {
      case 'Gen Z': return 'bg-gradient-to-r from-purple-500 to-pink-500';
      case 'Gen Alpha': return 'bg-gradient-to-r from-green-400 to-blue-500';
      case 'Boomer': return 'bg-gradient-to-r from-orange-400 to-red-500';
      case 'Millennial': return 'bg-gradient-to-r from-yellow-400 to-orange-500';
      default: return 'bg-gradient-to-r from-gray-400 to-gray-600';
    }
  };

  const handleCardClick = () => {
    setIsFlipped(!isFlipped);
    console.log('Card flipped:', isFlipped ? 'to front' : 'to back');
  };

  const handlePronunciation = () => {
    console.log('Playing pronunciation for:', slang.term);
    // TODO: Add text-to-speech functionality
  };

  return (
    <div className="perspective-1000 w-full max-w-md mx-auto">
      <div 
        className={`relative w-full h-96 transition-transform duration-700 transform-style-preserve-3d ${
          isFlipped ? 'rotate-y-180' : ''
        }`}
      >
        {/* Front of card */}
        <Card 
          className={`absolute inset-0 backface-hidden cursor-pointer hover-elevate bg-gradient-to-br from-purple-900/20 to-pink-900/20 border-2 border-primary/30 ${
            isFlipped ? 'rotate-y-180' : ''
          }`}
          onClick={handleCardClick}
          data-testid={`card-slang-${slang.id}`}
        >
          <CardContent className="p-6 h-full flex flex-col justify-center items-center text-center">
            <div className="mb-4">
              <Badge 
                className={`${getGenerationColor(slang.generation)} text-white font-bold px-3 py-1 text-sm`}
                data-testid={`badge-generation-${slang.generation.toLowerCase().replace(' ', '-')}`}
              >
                {slang.generation}
              </Badge>
            </div>
            
            <h2 className="font-display text-4xl md:text-5xl text-primary mb-4 break-words" data-testid="text-slang-term">
              {slang.term}
            </h2>
            
            {slang.pronunciation && (
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  handlePronunciation();
                }}
                className="mb-4"
                data-testid="button-pronunciation"
              >
                <Volume2 className="w-4 h-4 mr-2" />
                /{slang.pronunciation}/
              </Button>
            )}
            
            <p className="text-muted-foreground text-lg font-casual">
              Tap to reveal meaning ✨
            </p>
          </CardContent>
        </Card>

        {/* Back of card */}
        <Card 
          className={`absolute inset-0 backface-hidden cursor-pointer hover-elevate bg-gradient-to-br from-green-900/20 to-blue-900/20 border-2 border-green-400/30 rotate-y-180 ${
            !isFlipped ? 'rotate-y-180' : ''
          }`}
          onClick={handleCardClick}
          data-testid={`card-definition-${slang.id}`}
        >
          <CardContent className="p-6 h-full flex flex-col justify-center">
            <div className="text-center mb-6">
              <Badge 
                className={`${getGenerationColor(slang.generation)} text-white font-bold px-3 py-1 text-sm`}
              >
                {slang.generation}
              </Badge>
              <h3 className="font-display text-2xl text-primary mt-2" data-testid="text-definition-term">
                {slang.term}
              </h3>
            </div>
            
            <div className="space-y-4 text-center">
              <div>
                <h4 className="font-semibold text-green-400 mb-2">Definition:</h4>
                <p className="text-foreground" data-testid="text-definition">
                  {slang.definition}
                </p>
              </div>
              
              <div>
                <h4 className="font-semibold text-blue-400 mb-2">Usage:</h4>
                <p className="text-muted-foreground font-casual" data-testid="text-usage">
                  {slang.usage}
                </p>
              </div>
              
              <div>
                <h4 className="font-semibold text-pink-400 mb-2">Example:</h4>
                <p className="text-foreground italic font-casual" data-testid="text-example">
                  "{slang.example}"
                </p>
              </div>
            </div>
            
            <div className="mt-6 flex justify-center">
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsFlipped(false);
                }}
                data-testid="button-flip-back"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Flip back
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}