import AppHeader from '../AppHeader';

export default function AppHeaderExample() {
  return (
    <div className="min-h-screen bg-background">
      <AppHeader onMenuClick={() => console.log('Menu clicked')} />
      <div className="p-8 text-center">
        <h2 className="font-display text-2xl text-primary mb-4">
          Header Demo
        </h2>
        <p className="text-muted-foreground font-casual">
          Try clicking the theme toggle! The header is sticky too ✨
        </p>
      </div>
    </div>
  );
}