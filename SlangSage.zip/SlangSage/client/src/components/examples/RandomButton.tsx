import { useState } from 'react';
import RandomButton from '../RandomButton';

export default function RandomButtonExample() {
  const [isLoading, setIsLoading] = useState(false);

  const handleRandom = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      console.log('Random slang found!');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-background p-4 flex items-center justify-center">
      <div className="text-center space-y-6">
        <h2 className="font-display text-3xl text-primary">
          Random Slang Generator
        </h2>
        <p className="text-muted-foreground font-casual">
          Feeling adventurous? Let fate decide your next brain rot! 
        </p>
        <RandomButton onRandom={handleRandom} isLoading={isLoading} />
      </div>
    </div>
  );
}