import SearchBar from '../SearchBar';

export default function SearchBarExample() {
  return (
    <div className="min-h-screen bg-background p-4 flex items-center justify-center">
      <div className="w-full max-w-lg">
        <h2 className="font-display text-2xl text-center text-primary mb-6">
          Search Demo
        </h2>
        <SearchBar 
          onSearch={(query) => console.log('Searching for:', query)}
        />
      </div>
    </div>
  );
}