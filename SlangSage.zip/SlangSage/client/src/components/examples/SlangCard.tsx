import SlangCard from '../SlangCard';

export default function SlangCardExample() {
  const mockSlang = {
    id: '1',
    term: 'no cap',
    definition: 'No lie, for real, telling the truth',
    generation: 'Gen Z' as const,
    usage: 'Used to emphasize that you\'re being honest or serious about something',
    example: 'That movie was actually fire, no cap!',
    pronunciation: 'noh kap'
  };

  return (
    <div className="min-h-screen bg-background p-4 flex items-center justify-center">
      <SlangCard slang={mockSlang} onNext={() => console.log('Next card requested')} />
    </div>
  );
}