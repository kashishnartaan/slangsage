import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSlangTermSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // GET /api/slang - Get all slang terms or search
  app.get("/api/slang", async (req, res) => {
    try {
      const { q } = req.query;
      const searchQuery = typeof q === 'string' ? q : '';
      
      const slangTerms = await storage.searchSlangTerms(searchQuery);
      res.json(slangTerms);
    } catch (error) {
      console.error('Error fetching slang terms:', error);
      res.status(500).json({ error: 'Failed to fetch slang terms' });
    }
  });

  // GET /api/slang/random - Get a random slang term
  app.get("/api/slang/random", async (req, res) => {
    try {
      const randomSlang = await storage.getRandomSlangTerm();
      res.json(randomSlang);
    } catch (error) {
      console.error('Error fetching random slang:', error);
      res.status(500).json({ error: 'Failed to fetch random slang term' });
    }
  });

  // GET /api/slang/:id - Get specific slang term by ID
  app.get("/api/slang/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const slangTerm = await storage.getSlangTermById(id);
      
      if (!slangTerm) {
        return res.status(404).json({ error: 'Slang term not found' });
      }
      
      res.json(slangTerm);
    } catch (error) {
      console.error('Error fetching slang term:', error);
      res.status(500).json({ error: 'Failed to fetch slang term' });
    }
  });

  // POST /api/slang - Create new slang term
  app.post("/api/slang", async (req, res) => {
    try {
      const validatedData = insertSlangTermSchema.parse(req.body);
      const newSlangTerm = await storage.createSlangTerm(validatedData);
      res.status(201).json(newSlangTerm);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          error: 'Invalid data', 
          details: error.errors 
        });
      }
      console.error('Error creating slang term:', error);
      res.status(500).json({ error: 'Failed to create slang term' });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
